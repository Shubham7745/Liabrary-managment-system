from django.db import models

# Create your models here.
class Customer(models.Model):
    custid=models.IntegerField()
    Divison=models.CharField(max_length=100)
    Project=models.CharField(max_length=100)
    Business=models.IntegerField()
    ActivePO=models.IntegerField()